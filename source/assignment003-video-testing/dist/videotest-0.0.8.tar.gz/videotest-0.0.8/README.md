The package contains basic video processing functions. It extracts images from videos, grayscales, resizes, processes and works with images.
